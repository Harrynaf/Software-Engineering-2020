﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public class Task
    {
        public string title;
        public string description;
        public string email;
        public double payment;
        public Boolean proof;
        public int id;

        public Task( int task_id, string email, string task_title, double payment_price, string task_description, Boolean proof_of_work)
        {
            this.title = task_title;
            this.description = task_description;
            this.email = email;
            this.payment = payment_price;
            this.proof = proof_of_work;
            this.id = task_id;
        }

        public Boolean CreateTask()
        {
            if (Verification.Verify(this) == true)
            {
                MessageBox.Show("Task Posted!");
                return true;
            }
            else
            {
                MessageBox.Show("There was a problem with your form,check again.");
                return false;
            }
        }

       public static ListBox GetTask(string title)
        { ListBox listBox1 = new ListBox();
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                cnn.Open();

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = cnn;
                    command.CommandText = "SELECT id,email,skillneed,payment,description FROM taskdb where skillneed like '"+ title + "' and active = 0";
                    //whenever you want to get some data from the database
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listBox1.Items.Add(reader["id"].ToString());
                            listBox1.Items.Add(reader["email"].ToString());
                            listBox1.Items.Add(reader["skillneed"].ToString());
                            listBox1.Items.Add(reader["payment"].ToString());
                            listBox1.Items.Add(reader["description"].ToString());
                        }
                    }
                    cnn.Close();
                }
                return listBox1;
                
            }
            catch (Exception l)
            {
                MessageBox.Show("Error:" + l);
                return listBox1;
            }
        }

        public static ListBox GetTask()
        {
            ListBox listBox1 = new ListBox();
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                cnn.Open();

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = cnn;
                    command.CommandText = "SELECT id,email,skillneed,payment,description FROM taskdb where active = 0";
                    //whenever you want to get some data from the database
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listBox1.Items.Add(reader["id"].ToString());
                            listBox1.Items.Add(reader["email"].ToString());
                            listBox1.Items.Add(reader["skillneed"].ToString());
                            listBox1.Items.Add(reader["payment"].ToString());
                            listBox1.Items.Add(reader["description"].ToString());
                        }
                    }
                    cnn.Close();
                }
                return listBox1;

            }
            catch (Exception l)
            {
                MessageBox.Show("Error:" + l);
                return listBox1;
            }
        }
    }
}
