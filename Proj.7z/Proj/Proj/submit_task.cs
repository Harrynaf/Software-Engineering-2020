﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class submit_task : Form
    {
        Employee User;
        Task selectedTask;
        public submit_task(Employee User,Task selectedTask)
        {
            this.User = User;
            this.selectedTask = selectedTask;
            InitializeComponent();
        }

        private void submit_task_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int employer_id=0;
            string employer_email=null;
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                var stm = "UPDATE taskdb SET candidates = CONCAT(IFNULL(candidates,''), '%" + User.email + "') WHERE id = '" + selectedTask.id + "'";
                var cmd = new MySqlCommand(stm, cnn);
                cnn.Open();
                int res = cmd.ExecuteNonQuery();

                // Check Error
                if (res < 0)
                {
                    Console.WriteLine("Problem with updating candidate");
                    cnn.Close();
                }
                else
                {
                    cnn.Close();
                }

                cnn.Open();


                var queryStr = "SELECT email FROM taskdb WHERE id='" + selectedTask.id + "'";
                var cmd1 = new MySqlCommand(queryStr, cnn);
                var dr = cmd1.ExecuteReader();
                // Now check if any rows returned.
                if (dr.HasRows)
                {
                    dr.Read();// Get first record.
                    employer_email = dr.GetString(0);
                    Console.WriteLine(employer_email);
                    cnn.Close();
                }
                cnn.Open();
                var queryStr1 = "SELECT id FROM user WHERE email='" + employer_email + "'";
                var cmd2 = new MySqlCommand(queryStr1, cnn);
                var dr1 = cmd2.ExecuteReader();
                if (dr1.HasRows)
                {

                    dr1.Read();
                    Console.WriteLine(dr1.GetString(0));
                    employer_id = int.Parse(dr1.GetString(0));// Get value of first column as string.
                    Console.WriteLine(employer_id);
                    cnn.Close();
                }

                cnn.Close();
                Chat message = new Chat(selectedTask.id, textBox1.Text);
                if (Chat.SendM(message) == true) {
                    MessageBox.Show("You have succesfuly applied for this task.");
                    this.Close();
            }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
