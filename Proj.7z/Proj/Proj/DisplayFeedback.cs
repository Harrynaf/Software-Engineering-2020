﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class DisplayFeedback : Form
    {
        public DisplayFeedback()
        {
            InitializeComponent();
        }
        public int task_id;
        public DisplayFeedback(int task_id)
        {
            this.task_id = task_id;
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            //select from taskdb values feedback where taskid=textBox.Text
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {
            using (SolidBrush br = new SolidBrush(Color.Red))
            {
                StringFormat sf = new StringFormat();
                sf.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                e.Graphics.DrawString(Feedback.GetFeedback(task_id), this.Font, br, point1, sf);

            }
        }
        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            point1 = new Point(e.X, e.Y);
        }

        bool flag = false;
        Point point1 = new Point();

        private void drawTexta_Click(object sender, EventArgs e)
        {
            flag = true;
            panel1.Refresh();
        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = Feedback.GetFeedback(task_id);
        }
    }
}
