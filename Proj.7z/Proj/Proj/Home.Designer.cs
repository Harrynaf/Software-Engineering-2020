﻿namespace Proj
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.CloseHomeButton = new System.Windows.Forms.Button();
            this.CommunicationButton = new System.Windows.Forms.Button();
            this.MyTaskProjButton = new System.Windows.Forms.Button();
            this.FindTaskProjButton = new System.Windows.Forms.Button();
            this.FeedbackButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.CloseHomeButton);
            this.panel1.Controls.Add(this.CommunicationButton);
            this.panel1.Controls.Add(this.MyTaskProjButton);
            this.panel1.Controls.Add(this.FindTaskProjButton);
            this.panel1.Controls.Add(this.FeedbackButton);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(346, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(549, 646);
            this.panel1.TabIndex = 0;
            // 
            // CloseHomeButton
            // 
            this.CloseHomeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.CloseHomeButton.ForeColor = System.Drawing.Color.White;
            this.CloseHomeButton.Location = new System.Drawing.Point(214, 569);
            this.CloseHomeButton.Name = "CloseHomeButton";
            this.CloseHomeButton.Size = new System.Drawing.Size(113, 42);
            this.CloseHomeButton.TabIndex = 2;
            this.CloseHomeButton.Text = "Close";
            this.CloseHomeButton.UseVisualStyleBackColor = false;
            this.CloseHomeButton.Click += new System.EventHandler(this.CloseHomeButton_Click);
            // 
            // CommunicationButton
            // 
            this.CommunicationButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.CommunicationButton.ForeColor = System.Drawing.Color.White;
            this.CommunicationButton.Location = new System.Drawing.Point(368, 228);
            this.CommunicationButton.Name = "CommunicationButton";
            this.CommunicationButton.Size = new System.Drawing.Size(150, 44);
            this.CommunicationButton.TabIndex = 1;
            this.CommunicationButton.Text = "Communication";
            this.CommunicationButton.UseVisualStyleBackColor = false;
            this.CommunicationButton.Click += new System.EventHandler(this.CommunicationButton_Click);
            // 
            // MyTaskProjButton
            // 
            this.MyTaskProjButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.MyTaskProjButton.ForeColor = System.Drawing.Color.White;
            this.MyTaskProjButton.Location = new System.Drawing.Point(323, 392);
            this.MyTaskProjButton.Name = "MyTaskProjButton";
            this.MyTaskProjButton.Size = new System.Drawing.Size(195, 69);
            this.MyTaskProjButton.TabIndex = 1;
            this.MyTaskProjButton.Text = "My Tasks / My Projects";
            this.MyTaskProjButton.UseVisualStyleBackColor = false;
            this.MyTaskProjButton.Click += new System.EventHandler(this.button4_Click);
            // 
            // FindTaskProjButton
            // 
            this.FindTaskProjButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.FindTaskProjButton.ForeColor = System.Drawing.Color.White;
            this.FindTaskProjButton.Location = new System.Drawing.Point(29, 392);
            this.FindTaskProjButton.Name = "FindTaskProjButton";
            this.FindTaskProjButton.Size = new System.Drawing.Size(195, 69);
            this.FindTaskProjButton.TabIndex = 1;
            this.FindTaskProjButton.Text = "Find Task / Post Task";
            this.FindTaskProjButton.UseVisualStyleBackColor = false;
            this.FindTaskProjButton.Click += new System.EventHandler(this.FindTaskProjButton_Click);
            // 
            // FeedbackButton
            // 
            this.FeedbackButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.FeedbackButton.ForeColor = System.Drawing.Color.White;
            this.FeedbackButton.Location = new System.Drawing.Point(29, 228);
            this.FeedbackButton.Name = "FeedbackButton";
            this.FeedbackButton.Size = new System.Drawing.Size(150, 44);
            this.FeedbackButton.TabIndex = 1;
            this.FeedbackButton.Text = "Feedback";
            this.FeedbackButton.UseVisualStyleBackColor = false;
            this.FeedbackButton.Click += new System.EventHandler(this.FeedbackButton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(549, 162);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(219, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 83);
            this.label1.TabIndex = 0;
            this.label1.Text = "UBER TASK";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 49F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.ClientSize = new System.Drawing.Size(1249, 805);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Home";
            this.Text = "Home";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button CommunicationButton;
        private System.Windows.Forms.Button MyTaskProjButton;
        private System.Windows.Forms.Button FindTaskProjButton;
        private System.Windows.Forms.Button FeedbackButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button CloseHomeButton;
        private System.Windows.Forms.Label label1;
    }
}