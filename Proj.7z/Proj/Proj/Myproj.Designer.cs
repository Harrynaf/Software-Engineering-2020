﻿namespace Proj
{
    partial class Myproj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.GoHomePageButton = new System.Windows.Forms.Button();
            this.HtasksList = new System.Windows.Forms.ListBox();
            this.HprojList = new System.Windows.Forms.ListBox();
            this.PAprojList = new System.Windows.Forms.ListBox();
            this.CAprojList = new System.Windows.Forms.ListBox();
            this.CAtasksList = new System.Windows.Forms.ListBox();
            this.PAtasksList = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.GoHomePageButton);
            this.panel1.Controls.Add(this.HtasksList);
            this.panel1.Controls.Add(this.HprojList);
            this.panel1.Controls.Add(this.PAprojList);
            this.panel1.Controls.Add(this.CAprojList);
            this.panel1.Controls.Add(this.CAtasksList);
            this.panel1.Controls.Add(this.PAtasksList);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(125, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1598, 1250);
            this.panel1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1017, 840);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(240, 132);
            this.button2.TabIndex = 6;
            this.button2.Text = "Employer Options";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(226, 823);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 129);
            this.button1.TabIndex = 5;
            this.button1.Text = "Employee Options";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GoHomePageButton
            // 
            this.GoHomePageButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.GoHomePageButton.ForeColor = System.Drawing.Color.White;
            this.GoHomePageButton.Location = new System.Drawing.Point(601, 849);
            this.GoHomePageButton.Name = "GoHomePageButton";
            this.GoHomePageButton.Size = new System.Drawing.Size(300, 115);
            this.GoHomePageButton.TabIndex = 4;
            this.GoHomePageButton.Text = "Go To Homepage";
            this.GoHomePageButton.UseVisualStyleBackColor = false;
            // 
            // HtasksList
            // 
            this.HtasksList.FormattingEnabled = true;
            this.HtasksList.ItemHeight = 31;
            this.HtasksList.Location = new System.Drawing.Point(176, 613);
            this.HtasksList.Name = "HtasksList";
            this.HtasksList.Size = new System.Drawing.Size(346, 159);
            this.HtasksList.TabIndex = 3;
            this.HtasksList.SelectedIndexChanged += new System.EventHandler(this.HtasksList_SelectedIndexChanged);
            // 
            // HprojList
            // 
            this.HprojList.FormattingEnabled = true;
            this.HprojList.ItemHeight = 31;
            this.HprojList.Location = new System.Drawing.Point(970, 595);
            this.HprojList.Name = "HprojList";
            this.HprojList.Size = new System.Drawing.Size(296, 159);
            this.HprojList.TabIndex = 3;
            this.HprojList.SelectedIndexChanged += new System.EventHandler(this.HprojList_SelectedIndexChanged);
            // 
            // PAprojList
            // 
            this.PAprojList.FormattingEnabled = true;
            this.PAprojList.ItemHeight = 31;
            this.PAprojList.Location = new System.Drawing.Point(970, 405);
            this.PAprojList.Name = "PAprojList";
            this.PAprojList.Size = new System.Drawing.Size(296, 128);
            this.PAprojList.TabIndex = 3;
            this.PAprojList.SelectedIndexChanged += new System.EventHandler(this.PAprojList_SelectedIndexChanged);
            // 
            // CAprojList
            // 
            this.CAprojList.FormattingEnabled = true;
            this.CAprojList.ItemHeight = 31;
            this.CAprojList.Location = new System.Drawing.Point(983, 226);
            this.CAprojList.Name = "CAprojList";
            this.CAprojList.Size = new System.Drawing.Size(296, 128);
            this.CAprojList.TabIndex = 3;
            this.CAprojList.SelectedIndexChanged += new System.EventHandler(this.CAprojList_SelectedIndexChanged);
            // 
            // CAtasksList
            // 
            this.CAtasksList.FormattingEnabled = true;
            this.CAtasksList.ItemHeight = 31;
            this.CAtasksList.Location = new System.Drawing.Point(176, 219);
            this.CAtasksList.Name = "CAtasksList";
            this.CAtasksList.Size = new System.Drawing.Size(346, 128);
            this.CAtasksList.TabIndex = 3;
            this.CAtasksList.SelectedIndexChanged += new System.EventHandler(this.CAtasksList_SelectedIndexChanged);
            // 
            // PAtasksList
            // 
            this.PAtasksList.FormattingEnabled = true;
            this.PAtasksList.ItemHeight = 31;
            this.PAtasksList.Location = new System.Drawing.Point(176, 405);
            this.PAtasksList.Name = "PAtasksList";
            this.PAtasksList.Size = new System.Drawing.Size(346, 159);
            this.PAtasksList.TabIndex = 3;
            this.PAtasksList.SelectedIndexChanged += new System.EventHandler(this.PAtasksList_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(252, 578);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 32);
            this.label5.TabIndex = 2;
            this.label5.Text = "History";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(201, 357);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "Pending Assigned";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1071, 560);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 32);
            this.label8.TabIndex = 2;
            this.label8.Text = "History";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(994, 357);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(246, 32);
            this.label7.TabIndex = 2;
            this.label7.Text = "Pending Assigned";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1011, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(255, 32);
            this.label9.TabIndex = 2;
            this.label9.Text = "Currently Assigned";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(216, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(255, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Currently Assigned";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(1046, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 82);
            this.label2.TabIndex = 1;
            this.label2.Text = "My Project";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(220, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 82);
            this.label1.TabIndex = 1;
            this.label1.Text = "My Tasks";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.label6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1598, 79);
            this.panel2.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(521, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(334, 83);
            this.label6.TabIndex = 1;
            this.label6.Text = "UBER TASK";
            // 
            // Myproj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1746, 1473);
            this.Controls.Add(this.panel1);
            this.Name = "Myproj";
            this.Text = "Myproj";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button GoHomePageButton;
        private System.Windows.Forms.ListBox HtasksList;
        private System.Windows.Forms.ListBox HprojList;
        private System.Windows.Forms.ListBox PAprojList;
        private System.Windows.Forms.ListBox CAprojList;
        private System.Windows.Forms.ListBox CAtasksList;
        private System.Windows.Forms.ListBox PAtasksList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
    }
}