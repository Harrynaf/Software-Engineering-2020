﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj
{
    public class Employer
    {
        public string email, name, surename, bio, password;
        public int age, phone, paymentaccount, id;


        public Employer(string email, string name, string surename, string bio, string password, int age, int phone, int paymentaccount, int id)
        {
            this.email = email;
            this.name = name;
            this.surename = surename;
            this.bio = bio;
            this.password = password;
            this.age = age;
            this.phone = phone;
            this.paymentaccount = paymentaccount;
            this.id = id;
        }
    }
}


   
    
       

