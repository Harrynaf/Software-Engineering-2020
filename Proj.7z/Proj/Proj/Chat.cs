﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Chat : Form
    {public int task_id,employee_id, employer_id;
        public string text;
        //private readonly String chatters = new string;
        public Boolean message_check;
        public static ListBox GetM(int task_id) {

            ListBox listBox1 = new ListBox();
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                cnn.Open();

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = cnn;
                    command.CommandText = "SELECT taskid,text FROM commdb where taskid like '" + task_id + "' ";
                    //whenever you want to get some data from the database
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listBox1.Items.Add(reader["taskid"].ToString());
                            listBox1.Items.Add(reader["text"].ToString());
                        }
                    }
                    cnn.Close();
                }
                return listBox1;

            }
            catch (Exception l)
            {
                MessageBox.Show("Error:" + l);
                return listBox1;
            }
        }
        public Chat(int task_id, String text) { 
            this.task_id= task_id;
            this.text = text;
        }
        public static Boolean SendM(Chat message) {
            
           
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                var stm = "insert into commdb (taskid,text) values ('" + message.task_id + "','" + message.text + "')";
                var cmd = new MySqlCommand(stm, cnn);
                cnn.Open();
                int res = cmd.ExecuteNonQuery();

                // Check Error
                if (res < 0)
                {
                    cnn.Close();
                    return false;
                }
                else
                {
                    cnn.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }



        }
        public Chat()
        {

            InitializeComponent(); }
    
        private void Chat_Load(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //select count from commdb where taskid=textBox2.Text
            //update 2 seconds
            Message_list.Items.AddRange(new object[] { "Taskid | Message" });
            for (int i = 0; i < Chat.GetM(int.Parse(textBox2.Text)).Items.Count; i = i + 2)
            {
                Message_list.Items.AddRange(new object[] {
            ""+Chat.GetM(int.Parse(textBox2.Text)).Items[i].ToString()+"|"+Chat.GetM(int.Parse(textBox2.Text)).Items[i+1].ToString()+""});
            }

            Message_list.Refresh();
            Message_list.Update();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Message_list.Items.Clear();
            button2_Click(sender,e);
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Chat message = new Chat(int.Parse(textBox2.Text), textBox1.Text);
            Chat.SendM(message);
            MessageBox.Show("Sent");
        }
    }
    }

