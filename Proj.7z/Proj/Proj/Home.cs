﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Home : Form
    {
        Employee User;
        public Home(Employee User)
        {
            this.User = User;
            InitializeComponent();
        }

        private void CommunicationButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Chat().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Myproj(User).Show();
        }

        private void CloseHomeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Application.Exit();
        }

        private void FeedbackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Feedback(User).Show();
        }

        private void FindTaskProjButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Find_Post(User).Show();
        }
    }
}
