﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Find_Post : Form
    {
        Employee User;
        public Find_Post(Employee User)
        {
            this.User = User;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new find_task(User).Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new post_task(User).Show();
        }
    }
}
