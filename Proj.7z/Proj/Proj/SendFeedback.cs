﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class SendFeedback : Form
    {
        Employee User;
        public int task_id,user_id;
        public SendFeedback(Employee User ,int user_id, int task_id)
        {
            this.user_id = user_id;
            this.task_id = task_id;
            this.User=User;
            InitializeComponent();
        }

        public SendFeedback()
        {
            
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Feedback feedback = new Feedback(User,task_id, textBox1.Text);
            if (Feedback.SendFeedback(feedback) == true)
            MessageBox.Show("Sent!");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
