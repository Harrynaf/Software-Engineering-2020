﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class find_task : Form
    {
        Employee User;
        string text;
        public find_task(Employee User)
        {
            this.User = User;
            InitializeComponent();
        }

        private void find_task_Load(object sender, EventArgs e)
        {

        }

        private void Task_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            Task_list.MultiColumn = true;
            text = Task_list.GetItemText(Task_list.SelectedItem);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Task_list.Items.AddRange(new object[] { "Taskid| Employer|Needs|Payment|Description" });
            for (int i = 0; i < Task.GetTask(textBox1.Text).Items.Count; i=i+5) { 
            Task_list.Items.AddRange(new object[] {
            ""+Task.GetTask(textBox1.Text).Items[i].ToString()+"|"+Task.GetTask(textBox1.Text).Items[i+1].ToString()+"|"+Task.GetTask(textBox1.Text).Items[i+2].ToString()+"|"+Task.GetTask(textBox1.Text).Items[i+3].ToString()+"|"+Task.GetTask(textBox1.Text).Items[i+4].ToString()+""}); }

            Task_list.Refresh();
            Task_list.Update();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            char[] delimiterChars = { ' ', '|'};
            Console.WriteLine(text);
            String[] words = text.Split(delimiterChars);

            foreach (var word in words)
            {
                System.Console.WriteLine($"<{word}>");
            }
            Task selectedTask = new Task(int.Parse(words[0]), words[1],words[2],double.Parse(words[3]),words[4],false);
            Console.WriteLine(text);
            new submit_task(User,selectedTask).Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Task_list.Items.AddRange(new object[] { "Taskid| Employer|Needs|Payment|Description" });
            for (int i = 0; i < Task.GetTask().Items.Count; i = i + 5)
            {
                Task_list.Items.AddRange(new object[] {
            ""+Task.GetTask().Items[i].ToString()+"|"+Task.GetTask().Items[i+1].ToString()+"|"+Task.GetTask().Items[i+2].ToString()+"|"+Task.GetTask().Items[i+3].ToString()+"|"+Task.GetTask().Items[i+4].ToString()+""});
            }

            Task_list.Refresh();
            Task_list.Update();

        }
    }
}
