﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Feedback : Form
    {
        public int task_id, employee_id;
        public string text;
        Employee User;

        public Feedback(Employee User,int task_id,string text)
        {
            this.task_id = task_id;
            this.text = text;
            this.employee_id = User.id;
   
        }
        public static string GetFeedback(int task_id) {

            string feedback = null;
            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                cnn.Open();

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = cnn;
                    command.CommandText = "SELECT feedback FROM taskdb where id like '" + task_id + "' ";
                    //whenever you want to get some data from the database
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                           feedback=reader["feedback"].ToString();
                        }
                    }
                    cnn.Close();
                }
                return feedback;

            }
            catch (Exception l)
            {
                MessageBox.Show("Error:" + l);
                return feedback;
            }




        }
        public static Boolean SendFeedback(Feedback feedback) {



            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                var stm = "insert into taskdb (feedback) values ('" + feedback.text + "') where (id = '" + feedback.task_id + "' and  assignedto='"+ feedback.employee_id + "') or ( id = '" + feedback.task_id + "' and email='" + feedback.employee_id + "' ) ";
                var cmd = new MySqlCommand(stm, cnn);
                cnn.Open();
                int res = cmd.ExecuteNonQuery();

                // Check Error
                if (res < 0)
                {
                    cnn.Close();
                    return false;
                }
                else
                {
                    cnn.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }

        }
        public Feedback(Employee User)
        {
            this.User = User;
            InitializeComponent();
        }


        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Feedback_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            new SendFeedback(User,User.id,int.Parse(textBox1.Text)).Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            new DisplayFeedback(int.Parse(textBox1.Text)).Show();
        }
    }

    public class boolean
    {
    }
}

